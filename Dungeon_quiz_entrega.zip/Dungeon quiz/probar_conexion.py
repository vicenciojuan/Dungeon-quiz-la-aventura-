import mysql.connector

try:
    conexion = mysql.connector.connect(
        host="localhost",
        port=3306,
        user="root",
        password="",
        database="dungeon_quiz"
    )

    print("¡Conexión exitosa con Dungeon Quiz!")

    cursor = conexion.cursor()
    cursor.execute("SELECT DATABASE()")
    print("Base de datos:", cursor.fetchone()[0])

    cursor.close()
    conexion.close()

except mysql.connector.Error as error:
    print("Error de conexión:", error)
